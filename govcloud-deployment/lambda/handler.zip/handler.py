"""
Program Intake Form Handler
AWS Lambda function for AWS GovCloud (us-gov-west-1 or us-gov-east-1)

Routes:
  POST  /program-intake    – Store referral in DynamoDB + send SES notification
  GET   /referrals         – Return referrals for the caller's state (requires Cognito JWT)
  PATCH /referrals/{id}    – Update referral status (requires Cognito JWT)
  GET   /admin/users       – List all Cognito dashboard users (requires Cognito JWT)
  POST  /admin/users       – Create a new Cognito dashboard user (requires Cognito JWT)
  PATCH /admin/users       – Enable or disable a Cognito dashboard user (requires Cognito JWT)

Required environment variables:
  TABLE_NAME         – DynamoDB table name
  USER_POOL_ID       – Cognito User Pool ID for admin user management
  SENDER_EMAIL       – SES-verified sender (e.g. no-reply@haltreferral.org)
  NOTIFICATION_EMAIL – Notification recipient (e.g. support@halt360.org)
  ALLOWED_ORIGIN     – Site domain for CORS (e.g. https://www.haltreferral.org)

Authentication:
  All routes except POST /program-intake are protected by an API Gateway JWT
  authorizer backed by Cognito. The Lambda receives the validated claims in
  event["requestContext"]["authorizer"]["jwt"]["claims"]. No auth code is needed
  here — API Gateway rejects unauthenticated requests before Lambda is invoked.

  Each Cognito user has a custom:state attribute (e.g. "Alaska") that determines
  which referrals they can see. The by-state GSI is queried using this value.
"""

import json
import logging
import os
import uuid
from datetime import datetime, timezone

import boto3
from boto3.dynamodb.conditions import Attr, Key
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource("dynamodb")
ses      = boto3.client("ses")
cognito  = boto3.client("cognito-idp")

# Maps landing_page values (submitted by intake forms) to US states.
# Add new entries here when programs in new states are launched.
PROGRAM_STATE = {
    "Lose Weight":          "Alaska",
    "Lower Blood Pressure": "Alaska",
    "Lower Blood Sugar":    "Alaska",
}


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _cors_headers() -> dict:
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin":  os.environ.get("ALLOWED_ORIGIN", ""),
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,POST,PATCH,OPTIONS",
    }


def _respond(status_code: int, body: dict) -> dict:
    return {
        "statusCode": status_code,
        "headers": _cors_headers(),
        "body": json.dumps(body, default=str),
    }


def _get_table():
    table_name = os.environ.get("TABLE_NAME", "")
    if not table_name:
        raise ValueError("TABLE_NAME environment variable is not set")
    return dynamodb.Table(table_name)


def _get_caller_state(event: dict) -> str:
    """Extract the custom:state claim from the Cognito JWT (already validated by API GW)."""
    claims = (
        event.get("requestContext", {})
             .get("authorizer", {})
             .get("jwt", {})
             .get("claims", {})
    )
    return claims.get("custom:state", "").strip()


# ─────────────────────────────────────────────────────────────────────────────
# Route: POST /program-intake
# ─────────────────────────────────────────────────────────────────────────────

def _handle_intake(body: dict) -> dict:
    name  = (body.get("name")  or "").strip()
    email = (body.get("email") or "").strip()
    if not name or not email:
        return _respond(400, {"error": "Fields 'name' and 'email' are required"})

    zipcode      = (body.get("zipcode")      or "").strip()
    landing_page = (body.get("landing_page") or "Unknown Program").strip()
    state        = PROGRAM_STATE.get(landing_page, "Unknown")

    now           = datetime.now(timezone.utc).isoformat()
    submission_id = str(uuid.uuid4())

    item = {
        "submission_id":       submission_id,
        "submitted_at":        now,
        "landing_page":        landing_page,
        "program_of_interest": landing_page,
        "state":               state,
        "name":                name,
        "email":               email,
        "phone":               (body.get("phone")      or "").strip(),
        "zipcode":             zipcode,
        "motivation":          (body.get("motivation") or "").strip(),
        "status":              "new",
    }

    try:
        _get_table().put_item(Item=item)
        logger.info("Submission %s stored | program: %s | state: %s", submission_id, landing_page, state)
    except (ClientError, ValueError) as exc:
        logger.error("DynamoDB put_item failed: %s", exc)
        return _respond(500, {"error": "Failed to store submission"})

    _send_notification(submission_id, landing_page)

    return _respond(200, {"message": "Submission received. A team member will follow up soon."})


# ─────────────────────────────────────────────────────────────────────────────
# Route: GET /referrals
# ─────────────────────────────────────────────────────────────────────────────

def _handle_get_referrals(event: dict) -> dict:
    user_state = _get_caller_state(event)
    if not user_state:
        logger.error("No custom:state claim in JWT — cannot filter referrals")
        return _respond(403, {"error": "User account is missing a state assignment. Contact an administrator."})

    try:
        table    = _get_table()
        response = table.query(
            IndexName="by-state",
            KeyConditionExpression=Key("state").eq(user_state),
            ScanIndexForward=False,  # newest first via submitted_at RANGE key
        )
        items = response.get("Items", [])

        while "LastEvaluatedKey" in response:
            response = table.query(
                IndexName="by-state",
                KeyConditionExpression=Key("state").eq(user_state),
                ExclusiveStartKey=response["LastEvaluatedKey"],
                ScanIndexForward=False,
            )
            items.extend(response.get("Items", []))

        logger.info("Returning %d referrals for state=%s", len(items), user_state)
        return _respond(200, {"referrals": items, "count": len(items), "state": user_state})

    except (ClientError, ValueError) as exc:
        logger.error("DynamoDB query failed: %s", exc)
        return _respond(500, {"error": "Failed to retrieve referrals"})


# ─────────────────────────────────────────────────────────────────────────────
# Route: PATCH /referrals/{submission_id}
# ─────────────────────────────────────────────────────────────────────────────

VALID_STATUSES = {"new", "contacted", "enrolled", "not_eligible", "no_response"}

def _handle_update_referral(event: dict, path: str) -> dict:
    parts         = path.rstrip("/").split("/")
    submission_id = parts[-1] if len(parts) >= 2 else ""
    if not submission_id:
        return _respond(400, {"error": "Missing submission_id in path"})

    try:
        body       = json.loads(event.get("body") or "{}")
        new_status = (body.get("status") or "").strip().lower()
    except (json.JSONDecodeError, TypeError):
        return _respond(400, {"error": "Invalid request body"})

    if new_status not in VALID_STATUSES:
        return _respond(400, {
            "error": f"Invalid status. Must be one of: {', '.join(sorted(VALID_STATUSES))}"
        })

    try:
        table = _get_table()
        table.update_item(
            Key={"submission_id": submission_id},
            UpdateExpression="SET #s = :s, updated_at = :u",
            ExpressionAttributeNames={"#s": "status"},
            ExpressionAttributeValues={
                ":s": new_status,
                ":u": datetime.now(timezone.utc).isoformat(),
            },
            ConditionExpression=Attr("submission_id").exists(),
        )
        logger.info("Submission %s status updated to %s", submission_id, new_status)
        return _respond(200, {"message": f"Status updated to '{new_status}'"})

    except ClientError as exc:
        error_code = exc.response["Error"]["Code"]
        if error_code == "ConditionalCheckFailedException":
            return _respond(404, {"error": "Submission not found"})
        logger.error("DynamoDB update_item failed: %s", exc)
        return _respond(500, {"error": "Failed to update submission"})


# ─────────────────────────────────────────────────────────────────────────────
# SES notification (no PII)
# ─────────────────────────────────────────────────────────────────────────────

def _send_notification(submission_id: str, program: str) -> None:
    sender     = os.environ.get("SENDER_EMAIL", "")
    recipients = [
        addr.strip()
        for addr in os.environ.get("NOTIFICATION_EMAIL", "").split(",")
        if addr.strip()
    ]
    if not sender or not recipients:
        logger.warning("SENDER_EMAIL or NOTIFICATION_EMAIL not set — skipping")
        return

    allowed_origin = os.environ.get("ALLOWED_ORIGIN", "").rstrip("/")
    if not allowed_origin or allowed_origin == "*":
        logger.warning("ALLOWED_ORIGIN not set or is '*' — dashboard link omitted from notification email")
        dashboard_link = None
    else:
        dashboard_link = f"{allowed_origin}/program_landings/dashboard.html?id={submission_id}"

    subject = "New Referral Received"
    if dashboard_link:
        text_body = (
            f"A new referral has been submitted on the {program} landing page.\n\n"
            f"Click the link below to view this referral in the secure dashboard:\n"
            f"{dashboard_link}\n\n"
            f"You will be prompted to log in when the page loads.\n\n"
            f"Submission ID: {submission_id}\n\n"
            f"This is an automated notification. No personal information "
            f"is included in this email for security purposes."
        )
        dashboard_button = f"""
  <p>Click the button below to view this referral directly in the secure dashboard.
     You will be prompted to log in when the page loads.</p>
  <p style="margin:28px 0;">
    <a href="{dashboard_link}"
       style="display:inline-block;background-color:#003366;color:#fff;
              padding:12px 28px;text-decoration:none;border-radius:6px;
              font-weight:bold;font-size:15px;">
      View This Referral
    </a>
  </p>"""
    else:
        text_body = (
            f"A new referral has been submitted on the {program} landing page.\n\n"
            f"Log in to the dashboard to view this referral.\n\n"
            f"Submission ID: {submission_id}\n\n"
            f"This is an automated notification. No personal information "
            f"is included in this email for security purposes."
        )
        dashboard_button = "<p>Log in to the dashboard to view this referral.</p>"

    html_body = f"""<!DOCTYPE html>
<html lang="en">
<body style="font-family:Arial,sans-serif;color:#1a1a1a;line-height:1.6;max-width:560px;margin:0 auto;padding:24px;">
  <h2 style="color:#003366;">New Referral Received</h2>
  <p>A new referral has been submitted on the <strong>{program}</strong> landing page.</p>
  {dashboard_button}
  <p style="color:#595959;font-size:13px;">Submission ID: {submission_id}</p>
  <hr style="border:none;border-top:1px solid #ddd;margin:20px 0;"/>
  <p style="color:#888;font-size:12px;">
    Automated notification from the HALT referral system.
    No personal information is included in this email.
    All referral data is stored securely within the GovCloud environment.
  </p>
</body>
</html>"""

    try:
        ses.send_email(
            Source=sender,
            Destination={"ToAddresses": recipients},
            Message={
                "Subject": {"Data": subject,   "Charset": "UTF-8"},
                "Body": {
                    "Text": {"Data": text_body, "Charset": "UTF-8"},
                    "Html": {"Data": html_body,  "Charset": "UTF-8"},
                },
            },
        )
        logger.info("Notification sent for submission %s", submission_id)
    except ClientError as exc:
        logger.error("Failed to send notification email: %s", exc)


# ─────────────────────────────────────────────────────────────────────────────
# Routes: GET / POST / PATCH /admin/users
# ─────────────────────────────────────────────────────────────────────────────

def _get_user_pool_id() -> str:
    pool_id = os.environ.get("USER_POOL_ID", "")
    if not pool_id:
        raise ValueError("USER_POOL_ID environment variable is not set")
    return pool_id


def _handle_list_users() -> dict:
    try:
        pool_id = _get_user_pool_id()
        users   = []
        kwargs  = {"UserPoolId": pool_id, "Limit": 60}
        while True:
            resp = cognito.list_users(**kwargs)
            for u in resp.get("Users", []):
                attrs = {a["Name"]: a["Value"] for a in u.get("Attributes", [])}
                users.append({
                    "email":   attrs.get("email", u["Username"]),
                    "state":   attrs.get("custom:state", ""),
                    "status":  u.get("UserStatus", ""),
                    "enabled": u.get("Enabled", True),
                    "created": u.get("UserCreateDate", "").isoformat() if u.get("UserCreateDate") else "",
                })
            pagination_token = resp.get("PaginationToken")
            if not pagination_token:
                break
            kwargs["PaginationToken"] = pagination_token

        users.sort(key=lambda u: u["email"])
        logger.info("Listed %d users", len(users))
        return _respond(200, {"users": users, "count": len(users)})

    except (ClientError, ValueError) as exc:
        logger.error("list_users failed: %s", exc)
        return _respond(500, {"error": "Failed to list users"})


def _handle_create_user(body: dict) -> dict:
    email = (body.get("email") or "").strip().lower()
    state = (body.get("state") or "").strip()
    if not email or not state:
        return _respond(400, {"error": "Fields 'email' and 'state' are required"})

    try:
        pool_id = _get_user_pool_id()
        cognito.admin_create_user(
            UserPoolId=pool_id,
            Username=email,
            UserAttributes=[
                {"Name": "email",         "Value": email},
                {"Name": "email_verified", "Value": "true"},
                {"Name": "custom:state",  "Value": state},
            ],
            DesiredDeliveryMediums=["EMAIL"],
        )
        logger.info("Created user %s for state %s", email, state)
        return _respond(200, {"message": f"User {email} created. Temporary password sent by email."})

    except ClientError as exc:
        code = exc.response["Error"]["Code"]
        if code == "UsernameExistsException":
            return _respond(409, {"error": f"A user with email {email} already exists."})
        logger.error("admin_create_user failed: %s", exc)
        return _respond(500, {"error": "Failed to create user"})


def _handle_toggle_user(body: dict) -> dict:
    email   = (body.get("email") or "").strip().lower()
    enabled = body.get("enabled")
    if not email or enabled is None:
        return _respond(400, {"error": "Fields 'email' and 'enabled' are required"})

    try:
        pool_id = _get_user_pool_id()
        if enabled:
            cognito.admin_enable_user(UserPoolId=pool_id, Username=email)
            logger.info("Enabled user %s", email)
        else:
            cognito.admin_disable_user(UserPoolId=pool_id, Username=email)
            logger.info("Disabled user %s", email)
        return _respond(200, {"message": f"User {email} {'enabled' if enabled else 'disabled'}."})

    except ClientError as exc:
        code = exc.response["Error"]["Code"]
        if code == "UserNotFoundException":
            return _respond(404, {"error": f"User {email} not found."})
        logger.error("admin_enable/disable_user failed: %s", exc)
        return _respond(500, {"error": "Failed to update user"})


# ─────────────────────────────────────────────────────────────────────────────
# Main handler — route dispatcher
# ─────────────────────────────────────────────────────────────────────────────

def lambda_handler(event, context):
    request_context = event.get("requestContext", {})
    http = request_context.get("http", {})
    logger.info(
        "Request received method=%s path=%s requestId=%s",
        http.get("method", "").upper(),
        http.get("path", ""),
        request_context.get("requestId", ""),
    )
    method = http.get("method", "").upper()
    path   = http.get("path", "")

    # CORS pre-flight
    if method == "OPTIONS":
        return _respond(200, {})

    # Parse body (for POST and PATCH)
    body = {}
    if method in ("POST", "PATCH"):
        try:
            body = json.loads(event.get("body") or "{}")
        except (json.JSONDecodeError, TypeError):
            return _respond(400, {"error": "Invalid JSON body"})

    # Route dispatch
    if method == "POST" and path == "/program-intake":
        return _handle_intake(body)

    if method == "GET" and path == "/referrals":
        return _handle_get_referrals(event)

    if method == "PATCH" and path.startswith("/referrals/"):
        return _handle_update_referral(event, path)

    if method == "GET" and path == "/admin/users":
        return _handle_list_users()

    if method == "POST" and path == "/admin/users":
        return _handle_create_user(body)

    if method == "PATCH" and path == "/admin/users":
        return _handle_toggle_user(body)

    return _respond(404, {"error": "Not found"})
